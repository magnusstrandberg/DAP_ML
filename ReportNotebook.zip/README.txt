1. 	Extract the zip into a folder

2. 	Upload the folder content to the jupyter server, 
	matlab-sripts not needed to execute the pyhton code. 
	The rest is mandatory!